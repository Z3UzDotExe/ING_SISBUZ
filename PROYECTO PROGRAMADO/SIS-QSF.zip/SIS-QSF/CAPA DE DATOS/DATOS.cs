﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Security.Cryptography;

namespace Datos
{
    public class DATOS
    {
        public MySqlConnection cn = null;
        public MySqlDataAdapter mda = null;
        public String departamento, estatus, prioridad, claveQSF;
        /// <summary>
        /// Metodo que realiza busqueda, utilizando como clausulas 
        /// departamento, estatus y prioridad
        /// </summary>
        /// <param name="departamento"></param>
        /// <param name="estatus"></param>
        /// <param name="prioridad"></param>
        /// <returns>
        /// Retorna un formato tipo DataSet.
        /// </returns>
        public DataSet realizarBusqueda()
        {
            DataSet ds=null;
            try
            {
                ds = new DataSet();
                string strSQL = "select * from qsf where Departamento = @Pdepartamento and Estatus= @Pestatus and Prioridad=@Pprioridad;";
                MySqlCommand comando = new MySqlCommand(strSQL, Conexion.ObtenerConexion());
                comando.Parameters.AddWithValue("@Pdepartamento", departamento);
                comando.Parameters.AddWithValue("@Pestatus", estatus);
                comando.Parameters.AddWithValue("@Pprioridad", prioridad);
                mda = new MySqlDataAdapter(comando);
                mda.Fill(ds, "qsf");
                comando.Dispose();
            }
            catch (Exception io)
            {

            }
            finally
            {
                Conexion.ObtenerConexion().Close();
                Conexion.ObtenerConexion().Dispose();
            }
            return ds;
        }

        /// <summary>
        /// Metodo que realiza busqueda, utilizando como clausulas 
        /// departamento, estatus y prioridad
        /// </summary>
        /// <param name="departamento"></param>
        /// <param name="estatus"></param>
        /// <param name="prioridad"></param>
        /// <returns>
        /// Retorna un formato tipo DataSet.
        /// </returns>
        public DataSet obtenerLasQSF()
        {
            DataSet ds = null;
            try
            {
                ds = new DataSet();
                string strSQL = "select * from qsf ;";
                MySqlCommand comando = new MySqlCommand(strSQL, Conexion.ObtenerConexion());
                mda = new MySqlDataAdapter(comando);
                mda.Fill(ds, "qsf");
                comando.Dispose();
            }
            catch (Exception io)
            {

            }
            finally
            {
                Conexion.ObtenerConexion().Close();
                Conexion.ObtenerConexion().Dispose();
            }
            return ds;
        }


        public String usuario, contraseña;
        public bool verificarUsuario()
        {
            try
            {
                DataSet ds = new DataSet();
                String us = "";
                String con = "";
                SHA1 sha1 = new SHA1CryptoServiceProvider();
                string strSQL = "select * from administrador where Nombre_usuario=@usuario and Clave_usuario=sha1(@contraseña);";
                MySqlCommand comando = new MySqlCommand(strSQL, Conexion.ObtenerConexion());
                comando.Parameters.AddWithValue("@usuario", usuario);
                comando.Parameters.AddWithValue("@contraseña", contraseña);
                MySqlDataReader reader = comando.ExecuteReader();
                while (reader.Read())
                {
                    us = reader.GetString(0);
                    con = reader.GetString(1);
                }
                comando.Dispose();
                return (us.Equals(usuario)) && (!con.Equals(null));
            }
            catch (Exception e)
            {
               // MessageBox.Show("El usuario no se encuentra registrado", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            finally
            {
                Conexion.ObtenerConexion().Close();
                Conexion.ObtenerConexion().Dispose();
            }
        }

        public DataTable datosAdministracion()
        {
            DataTable ds = null;
            try
            {
                ds = new DataTable();

                string strSQL = "select usuarios.Nombre, usuarios.NoControl, usuarios.Telefono, usuarios.Correo," +
                    " usuarios.EsAlumno, qsf.Tipo_Servicio, qsf.Prioridad, qsf.Estatus, qsf.Departamento, qsf.Descripcion " +
                    "from usuarios inner join qsf on usuarios.ClaveUsuario = qsf.UsuarioSolicitante where qsf.ClaveQSF=@ClaveQSF;";
                
                MySqlCommand comando = new MySqlCommand(strSQL, Conexion.ObtenerConexion());
                comando.Parameters.AddWithValue("@ClaveQSF", claveQSF);
                mda = new MySqlDataAdapter(comando);
                mda.Fill(ds);
                comando.Dispose();
            }
            catch (Exception io)
            {

            }
            finally
            {
                Conexion.ObtenerConexion().Close();
                Conexion.ObtenerConexion().Dispose();
            }
            return ds;
        }

        public bool guardar()
        {
            
            try
            {
                string strSQL = "UPDATE qsf SET Departamento = @Pdepartamento, Estatus= @Pestatus, Prioridad=@Pprioridad " +
                            "WHERE claveQSF = @claveQSF";//variable donde contendra consulta mysql

                MySqlCommand sqlCom = new MySqlCommand(strSQL, Conexion.ObtenerConexion());//asigna la consulta y la conexion a la variable comando
                sqlCom.Parameters.AddWithValue("@Pdepartamento", departamento);//agregar los campos a agregar desde el exterior
                sqlCom.Parameters.AddWithValue("@Pestatus", estatus);
                sqlCom.Parameters.AddWithValue("@Pprioridad", prioridad);
                sqlCom.Parameters.AddWithValue("@claveQSF", claveQSF);
                sqlCom.ExecuteNonQuery();//ejecucion de los anteriores agregados
                Conexion.ObtenerConexion().Close();//cerrando conexion
                return true;
            }
            catch (Exception)
            {
                Conexion.ObtenerConexion().Close();
                Conexion.ObtenerConexion().Dispose();
                return false;
            }
        }

        class Conexion
        {
            public static MySqlConnection ObtenerConexion()
            {
                MySqlConnection conectar = new MySqlConnection("server=localhost; database=sisqsf; user=root; pwd='root'");
                conectar.Open();
                return conectar;
            }
        }
        
    }
}
