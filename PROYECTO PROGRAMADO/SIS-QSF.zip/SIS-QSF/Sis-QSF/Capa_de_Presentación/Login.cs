﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Sis_QSF.Capa_de_Datos;
using Sis_QSF.Capa_de_Modelo;

namespace Sis_QSF.Capa_de_Presentación
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
            this.CenterToScreen();
        }

        private void btnacceder_Click(object sender, EventArgs e)
        {
            if (txtusuario.Text.Equals("") && txtcontraseña.Text.Equals(""))
            {
                MessageBox.Show("Campos vacios", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                String usuario = txtusuario.Text;
                String contra = txtcontraseña.Text;

                Boolean resul = new verificarAcceso().verificarAccesoSistema(usuario, contra);
                if (resul)
                {
                    MessageBox.Show("Usuario correcto");
                }
                else
                {
                    MessageBox.Show("Usuario no valido");
                }
                
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
