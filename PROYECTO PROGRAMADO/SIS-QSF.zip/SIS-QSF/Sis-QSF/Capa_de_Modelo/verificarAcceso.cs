﻿using Sis_QSF.Capa_de_Datos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sis_QSF.Capa_de_Modelo
{
    public class verificarAcceso
    {


        public Boolean verificarAccesoSistema(String usuario, String contraseña)
        {
            Acceso ac = new Acceso();
            bool resultado = ac.Validar(usuario, contraseña);
            if (resultado)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
