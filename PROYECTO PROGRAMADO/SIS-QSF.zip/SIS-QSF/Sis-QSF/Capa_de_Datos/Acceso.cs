﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Windows.Forms;
using Sis_QSF.Capa_de_Presentación;

namespace Sis_QSF.Capa_de_Datos
{
    public class Acceso
    {
        public bool Validar(String usuario, String contraseña)
        {
            try
            { 
            DataSet ds = new DataSet();
            String us = "";
            String con = "";
            SHA1 sha1 = new SHA1CryptoServiceProvider();
            string strSQL = "select * from administrador where Nombre_usuario=@usuario and Clave_usuario=sha1(@contraseña);";
            MySqlCommand comando = new MySqlCommand(strSQL,Conexion.ObtenerConexion());
            comando.Parameters.AddWithValue("@usuario", usuario);
            comando.Parameters.AddWithValue("@contraseña", contraseña);
            MySqlDataReader reader = comando.ExecuteReader();
            while (reader.Read())
            {
                us = reader.GetString(0);
                con = reader.GetString(1);
            }
            comando.Dispose();
            return (us.Equals(usuario)) && (!con.Equals(null));
            }
            catch (Exception e)
            {
                MessageBox.Show("El usuario no se encuentra registrado", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            finally
            {
                Conexion.ObtenerConexion().Close();
                Conexion.ObtenerConexion().Dispose();
            }


        }

    }
}
