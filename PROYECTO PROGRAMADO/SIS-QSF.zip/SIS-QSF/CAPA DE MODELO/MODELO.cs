﻿using System;
using Datos;
using System.Data;
namespace Modelo
{
    public class MODELO
    {
        public String _usu, _cont, _departamento, _estatus, _prioridad,_claveQSF;
        public Boolean _estadoVerificacion,_estadoBusqueda;
      
        public void verificarAcceso()
        {
            DATOS objDatos = new DATOS();
            objDatos.usuario = _usu;
            objDatos.contraseña = _cont;
            _estadoVerificacion = objDatos.verificarUsuario();
        }

        public DataSet realizarBusqueda() {
            DATOS objDatos = new DATOS();
            objDatos.departamento = _departamento;
            objDatos.estatus = _estatus;
            objDatos.prioridad = _prioridad;
            return objDatos.realizarBusqueda();
        }

        public DataSet obtenerLasQSF()
        {
            DATOS objDatos = new DATOS();
            return objDatos.obtenerLasQSF();
        }

        public DataTable datosAdministracion()
        {
            DATOS objDatos = new DATOS();
            objDatos.claveQSF = _claveQSF;
            return objDatos.datosAdministracion();
        }

        public bool guardar()
        {
            DATOS objDatos = new DATOS();
            objDatos.departamento = _departamento;
            objDatos.estatus = _estatus;
            objDatos.prioridad = _prioridad;
            objDatos.claveQSF = _claveQSF;
            return objDatos.guardar();
        }
    }
}
