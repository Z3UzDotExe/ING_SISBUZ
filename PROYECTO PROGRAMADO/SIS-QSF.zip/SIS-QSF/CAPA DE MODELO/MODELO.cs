﻿using System;
using Datos;

namespace Modelo
{
    public class MODELO
    {
        public String _usu, _cont;
        public Boolean _estadoVerificacion;

        public void verificarAcceso()
        {
            DATOS objDatos = new DATOS();
            objDatos.usuario = _usu;
            objDatos.contraseña = _cont;
            _estadoVerificacion = objDatos.verificarUsuario();
        }
    }
}
