﻿using Modelo;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SIS_QSF
{
    public partial class Administracion : Form
    {
        int contador = 1;

        public Administracion()
        {
            InitializeComponent();
        }
        // cerrar formulario de administracion
        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Administracion_Load(object sender, EventArgs e)
        {
            lblID.Text = "" + contador;
            string prioridad="", departamento="", status="", desc = "";
            MODELO mostrarDatos = new MODELO();
            mostrarDatos._claveQSF = "1";
            DataTable tabla = new DataTable();
            tabla = mostrarDatos.datosAdministracion();
            var nombre = tabla.Rows[0]["Nombre"];
            lblNombre.Text = "" + nombre;
            var tel = tabla.Rows[0]["Telefono"];
            lblTelefono.Text = "" + tel;
            var control = tabla.Rows[0]["NoControl"];
            lblNocontrol.Text = "" + control;
            var correo = tabla.Rows[0]["Correo"];
            lblCorreo.Text = "" + correo;
            var alum = tabla.Rows[0]["EsAlumno"];
            lblAlumno.Text = "" + alum;
            var ser = tabla.Rows[0]["Tipo_Servicio"];
            lblServicio.Text = "" + ser;
            //validadcion para prioridad
            prioridad = "" + tabla.Rows[0]["Prioridad"];
            if (prioridad.Equals("Alta"))
            {
                radioButton1.Checked = true;
            }
            else if(prioridad.Equals("Media"))
            {
                radioButton2.Checked = true;
            }
            else if (prioridad.Equals("Baja"))
            {
                radioButton2.Checked = true;
            }
            //validacion de departamento
            departamento = "" + tabla.Rows[0]["Departamento"];
            cmbDepartamento.SelectedItem = departamento;
            //Validacion de Estatus
            status = "" + tabla.Rows[0]["Estatus"];
            cmbEstatus.SelectedItem = status;

            desc = "" + tabla.Rows[0]["Descripcion"];
            txtArea.Text = desc;
        }

        private void btnFiltrar_Click(object sender, EventArgs e)
        {

        }

        private void btnGuardad_Click(object sender, EventArgs e)
        {
            MODELO guardarQSF = new MODELO();
            guardarQSF._departamento = cmbDepartamento.SelectedItem.ToString();
            guardarQSF._estatus = cmbEstatus.SelectedItem.ToString();
            guardarQSF._claveQSF = ""+contador;
            if (radioButton1.Checked == true)
            {
                guardarQSF._prioridad = "Alta";
            }else if (radioButton2.Checked == true)
            {
                guardarQSF._prioridad = "Media";
            }else if (radioButton3.Checked == true)
            {
                guardarQSF._prioridad = "Baja";
            }
            if (guardarQSF.guardar())
            {
                MessageBox.Show("Guardado con exito", "Informacion");
            }
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            
        }

        private void btnSiguiente_Click(object sender, EventArgs e)
        {
            try
            {
                contador += 1;
                lblID.Text = "" + contador;
                string prioridad = "", departamento = "", status = "", desc = "";
                MODELO mostrarDatos = new MODELO();
                mostrarDatos._claveQSF = ""+contador;
                DataTable tabla = new DataTable();
                tabla = mostrarDatos.datosAdministracion();
                var nombre = tabla.Rows[0]["Nombre"];
                lblNombre.Text = "" + nombre;
                var tel = tabla.Rows[0]["Telefono"];
                lblTelefono.Text = "" + tel;
                var control = tabla.Rows[0]["NoControl"];
                lblNocontrol.Text = "" + control;
                var correo = tabla.Rows[0]["Correo"];
                lblCorreo.Text = "" + correo;
                var alum = tabla.Rows[0]["EsAlumno"];
                lblAlumno.Text = "" + alum;
                var ser = tabla.Rows[0]["Tipo_Servicio"];
                lblServicio.Text = "" + ser;
                //validadcion para prioridad
                prioridad = "" + tabla.Rows[0]["Prioridad"];
                if (prioridad.Equals("Alta"))
                {
                    radioButton1.Checked = true;
                }
                else if (prioridad.Equals("Media"))
                {
                    radioButton2.Checked = true;
                }
                else if (prioridad.Equals("Baja"))
                {
                    radioButton2.Checked = true;
                }
                //validacion de departamento
                departamento = "" + tabla.Rows[0]["Departamento"];
                cmbDepartamento.SelectedItem = departamento;
                //Validacion de Estatus
                status = "" + tabla.Rows[0]["Estatus"];
                cmbEstatus.SelectedItem = status;

                desc = "" + tabla.Rows[0]["Descripcion"];
                txtArea.Text = desc;
            }
            catch (Exception)
            {
                contador -= 1;
                lblID.Text = "" + contador;
                MessageBox.Show("No hay mas QSF","Exedido");
            }
        }

        private void btnAnterior_Click(object sender, EventArgs e)
        {
            try
            {
                contador -= 1;
                lblID.Text = "" + contador;
                string prioridad = "", departamento = "", status = "", desc = "";
                MODELO mostrarDatos = new MODELO();
                mostrarDatos._claveQSF = "" + contador;
                DataTable tabla = new DataTable();
                tabla = mostrarDatos.datosAdministracion();
                var nombre = tabla.Rows[0]["Nombre"];
                lblNombre.Text = "" + nombre;
                var tel = tabla.Rows[0]["Telefono"];
                lblTelefono.Text = "" + tel;
                var control = tabla.Rows[0]["NoControl"];
                lblNocontrol.Text = "" + control;
                var correo = tabla.Rows[0]["Correo"];
                lblCorreo.Text = "" + correo;
                var alum = tabla.Rows[0]["EsAlumno"];
                lblAlumno.Text = "" + alum;
                var ser = tabla.Rows[0]["Tipo_Servicio"];
                lblServicio.Text = "" + ser;
                //validadcion para prioridad
                prioridad = "" + tabla.Rows[0]["Prioridad"];
                if (prioridad.Equals("Alta"))
                {
                    radioButton1.Checked = true;
                }
                else if (prioridad.Equals("Media"))
                {
                    radioButton2.Checked = true;
                }
                else if (prioridad.Equals("Baja"))
                {
                    radioButton2.Checked = true;
                }
                //validacion de departamento
                departamento = "" + tabla.Rows[0]["Departamento"];
                cmbDepartamento.SelectedItem = departamento;
                //Validacion de Estatus
                status = "" + tabla.Rows[0]["Estatus"];
                cmbEstatus.SelectedItem = status;

                desc = "" + tabla.Rows[0]["Descripcion"];
                txtArea.Text = desc;
            }
            catch (Exception)
            {
                contador += 1;
                lblID.Text = "" + contador;
                MessageBox.Show("No hay mas QSF", "Exedido");
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
