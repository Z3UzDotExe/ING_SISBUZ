﻿using System;
using System.Windows.Forms;
using Modelo;


namespace SIS_QSF
{
    public partial class Busqueda : Form
    {
        

        public Busqueda()
        {
            InitializeComponent();
            cbxDepartamentos.SelectedIndex=0;
            cbxEstatus.SelectedIndex = 0;
            cbxPrioridad.SelectedIndex = 0;
            actualizarQSF();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCerrarFormBusqueda_Click(object sender, EventArgs e)
        {
            
        }


        /**
         * Cerrar el formulario de busqueda
         * **/
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {

            MODELO busquedaQSF = new MODELO();
            busquedaQSF._departamento = cbxDepartamentos.SelectedItem.ToString();
            busquedaQSF._estatus = cbxEstatus.SelectedItem.ToString();
            busquedaQSF._prioridad = cbxPrioridad.SelectedItem.ToString();
            dgvQSF.DataSource = busquedaQSF.realizarBusqueda().Tables["qsf"];
            dgvQSF.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;


        }

        private void btnFiltrar_Click(object sender, EventArgs e)
        {
            actualizarQSF();
        }

        public void actualizarQSF() {
            MODELO actualizarQSF = new MODELO();
            dgvQSF.DataSource = actualizarQSF.obtenerLasQSF().Tables["qsf"];
            dgvQSF.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void cbxDepartamentos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Busqueda_Load(object sender, EventArgs e)
        {

        }
    }
}
