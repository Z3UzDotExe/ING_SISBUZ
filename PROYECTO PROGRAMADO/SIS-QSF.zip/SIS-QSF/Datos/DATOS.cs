﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Security.Cryptography;

namespace Datos
{
    public class DATOS
    {

        public String usuario, contraseña;
        public bool verificarUsuario()
        {
            try
            {
                DataSet ds = new DataSet();
                String us = "";
                String con = "";
                SHA1 sha1 = new SHA1CryptoServiceProvider();
                string strSQL = "select * from administrador where Nombre_usuario=@usuario and Clave_usuario=sha1(@contraseña);";
                MySqlCommand comando = new MySqlCommand(strSQL, Conexion.ObtenerConexion());
                comando.Parameters.AddWithValue("@usuario", usuario);
                comando.Parameters.AddWithValue("@contraseña", contraseña);
                MySqlDataReader reader = comando.ExecuteReader();
                while (reader.Read())
                {
                    us = reader.GetString(0);
                    con = reader.GetString(1);
                }
                comando.Dispose();
                return (us.Equals(usuario)) && (!con.Equals(null));
            }
            catch (Exception e)
            {
               // MessageBox.Show("El usuario no se encuentra registrado", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            finally
            {
                Conexion.ObtenerConexion().Close();
                Conexion.ObtenerConexion().Dispose();
            }
        }

        class Conexion
        {
            public static MySqlConnection ObtenerConexion()
            {
                MySqlConnection conectar = new MySqlConnection("server=localhost; database=sisqsf; user=root; pwd='root'");
                conectar.Open();
                return conectar;
            }
        }
        
    }
}
