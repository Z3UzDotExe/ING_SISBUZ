﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using Modelo;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRESENTACION
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Btnacceder_Click(object sender, EventArgs e)
        {
            MODELO mOD_VerificarAcceso = new MODELO();
            mOD_VerificarAcceso._usu = txtusuario.Text.Trim();
            mOD_VerificarAcceso._cont = txtcontraseña.Text.Trim();
            mOD_VerificarAcceso.verificarAcceso();
            if (mOD_VerificarAcceso._estadoVerificacion)
            {
                MessageBox.Show("Usuario valido");
            }else
            {
                MessageBox.Show("Usuario no valido");
            }


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
        }
    }
}
