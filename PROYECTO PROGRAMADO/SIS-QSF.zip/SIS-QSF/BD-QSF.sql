create database sisqsf;
use sisqsf;
create table usuarios
(
NoControl varchar(50) not null primary key,
Nombre varchar(50) not null,
Telefono int not null,
Correo varchar(50) not null,
Alumno enum('Si','No')
);
create table qsfs
(
Clave int not null primary key,
NoControl varchar(50) not null,
Tipo_Servicio enum('Queja','Sugerencia','Felicitacion') not null,
Descripcion text not null,
Prioridad enum('Alta','Media','Baja') not null,
Estatus enum('No iniciada','En proceso', 'Finalizada') not null,
Departamento enum('Dpt.Academico','Dpt.Vinculacion','Dpt.Planeacion','Dpt.Calidad','Dpt.Administracion') not null,
constraint foreign key(NoControl)
references usuarios(NoControl)
);
create table administrador
(
Nombre_usuario varchar(50) not null,
Clave_usuario varchar(50) not null
);
insert into administrador(Nombre_usuario,Clave_usuario)
values
('Calidadrifa',sha1('cali2020'));
select * from administrador;